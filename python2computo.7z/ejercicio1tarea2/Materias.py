class Materias:
    
    materia1 = "lenguaje"
    materia1 = "ciencias"  
    materia1 = "matematica" 

materias = Materias 
print("al estudiante hoy le toca la materia: " + materias.materia1)
 