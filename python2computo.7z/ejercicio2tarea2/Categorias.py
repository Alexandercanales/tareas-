class Categorias:
    terror = "terror"
    comedia = "comedia "
    accion = "accion "  

    Pelicula = (input("ingrese la categoria "))  

    if terror == Pelicula:
     print("quiere ver  terror")
    elif comedia == Pelicula :
     print("quiere ver  comedia")
    elif accion == Pelicula:
     print("quiere ver  accion")   
        
        