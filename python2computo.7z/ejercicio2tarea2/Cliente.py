from Peliculas import Peliculas 
from Categorias import Categorias

class Cliente(Peliculas):
   pass
   def __init__(self, cliente1, disponible,categori):
       self.cliente1 = cliente1
       self.disponible = disponible
       self.categori = categori


   def final(self):
       return"el cliente {} va a ver la pelicula {} y es de la categoria  {}".format(self.cliente1,self.disponible ,self.categori,Peliculas,Categorias)
ver = Cliente("alexander", "el gato con botas ", " comedia " )
print(ver.final())      
        
  