from Categorias import Categorias  
class Peliculas(Categorias):
    pass
    
    def __init__(self, nombre, duracion):
        self.nombre=nombre
        self.duracion=duracion 
    def ver(self):
        return"el cliente quiere ver la pelicula {} y esta dura {} horas de la categoria {}".format(self.nombre,self.duracion,Categorias.Pelicula) 
mirar = Peliculas("Thor dios del trueno",3 )
print(mirar.ver())   
    
        