from Jugador1 import Jugador1
from Jugador2 import Jugador2
from Juego    import Juego
class Final(Jugador1,Jugador2,Juego):
    pass
    def __init__(self, batallaFinall):
       self.batallaFinall= batallaFinall
    def fin(self):
        return"el luchador {} le pega al jugador {} y quedan {} y {}".format(self.nombre1,self.nombre2,Juego.batalla , self.batallaFinall)
ResultadoFinal = Final
print(ResultadoFinal.fin)

