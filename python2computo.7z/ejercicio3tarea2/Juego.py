class Juego ():
    def __init__(self,golpe ,vida ):
        self.golpe=golpe
        self.vida =vida
    def batalla(self):
        return"golpean con fuerza de golpe {}% y quedan con un {}% ".format( self.golpe, self.vida)
BatallaFinal = Juego(30,70)
print(BatallaFinal.batalla())