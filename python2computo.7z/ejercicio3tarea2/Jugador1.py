class Jugador1 :
    def __init__(self, nombre1, poder1 ):
        self.nombre1=nombre1
        self.poder1=poder1
    def fight(self):
        return"el luchador {} tiene de poder {}".format(self.nombre1, self.poder1) 
Gerrear = Jugador1("goku" , 100)
print(Gerrear.fight())