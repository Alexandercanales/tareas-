class Jugador2 :
    def __init__(self, nombre2, poder2 ):
        self.nombre2=nombre2
        self.poder2=poder2 
    def combate(self):
        return"el luchador {} tiene de poder {}".format(self.nombre2, self.poder2) 
pelear =Jugador2("vegeta" , 100)
print(pelear.combate())